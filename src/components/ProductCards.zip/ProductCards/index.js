
export * from './DetailsSection';
// export * from './Navbar';
export * from './Slider';